package com.example.lonelytwitter;
import java.util.Date;

public class Sad extends CurrentMood {

    // Constructor accepting a date
    public Sad(Date date) {
        super(date);
    }

    // Default constructor setting the date to the current date (default)
    public Sad() {
        super();
    }

    // Method to return the string representation of the mood
    @Override
    public String getString() {
        return "Sad";
    }
}
