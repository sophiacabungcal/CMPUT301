package com.example.lonelytwitter;
import java.util.Date;

public abstract class CurrentMood {

    // Instance variables, encapsulated field
    private Date date;

    // Constructor accepting a date
    public CurrentMood(Date date) {
        this.date = date;
    }

    // Default constructor setting the date to the current date (default)
    public CurrentMood() {
        this.date = new Date();
    }

    // Getter for the date field
    public Date getDate() {
        return date;
    }

    // Setter for the date field
    public void setDate(Date date) {
        this.date = date;
    }

    // Abstract method to return the string representation of the mood
    public abstract String getString();
}
