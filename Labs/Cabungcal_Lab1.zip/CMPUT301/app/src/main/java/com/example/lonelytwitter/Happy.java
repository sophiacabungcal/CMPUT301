package com.example.lonelytwitter;
import java.util.Date;

public class Happy extends CurrentMood {

    // Constructor accepting a date
    public Happy(Date date) {
        super(date);
    }

    // Default constructor setting the date to the current date (default)
    public Happy() {
        super();
    }

    // Method to return the string representation of the mood
    @Override
    public String getString() {
        return "Happy";
    }
}
