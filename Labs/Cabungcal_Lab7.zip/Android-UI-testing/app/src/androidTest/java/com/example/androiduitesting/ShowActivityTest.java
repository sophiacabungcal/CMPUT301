package com.example.androiduitesting;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static androidx.test.espresso.intent.Intents.intended;
import static androidx.test.espresso.intent.matcher.IntentMatchers.hasComponent;

import android.content.Intent;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.rules.ActivityScenarioRule;

import org.junit.Rule;
import org.junit.Test;

public class ShowActivityTest {
    @Rule
    public ActivityScenarioRule<ShowActivity> scenario = new ActivityScenarioRule<ShowActivity>(ShowActivity.class);

    @Test
    public void testSwitchActivity() {
        onView(withId(R.id.city_list)).perform(click());
        onView(withId(R.id.city_name)).check(matches(isDisplayed()));
    }

    @Test
    public void testCityName() {
        Intent intent = new Intent(ApplicationProvider.getApplicationContext(), ShowActivity.class);
        intent.putExtra("CITY_NAME", "Edmonton");
        scenario.getScenario().launch(intent);
        onView(withId(R.id.city_name)).check(matches(withText("Edmonton")));
    }

    @Test
    public void testBackButton() {
        onView(withId(R.id.button_back)).perform(click());
        intended(hasComponent(MainActivity.class.getName()));
    }
}
