# Android-UI-testing
Android UI Testing - CMPUT 301 Lab 7   
Compile SDK - 34
